#!/bin/bash

./probSemSharedMemRestaurant | awk -f filter_log.awk

